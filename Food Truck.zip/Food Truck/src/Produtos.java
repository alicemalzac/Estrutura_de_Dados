import javax.swing.JOptionPane;

public class Produtos {
	private int tamanho, auxCod;
	private NoProduto inicio;
	private NoProduto fim;
		
	public Produtos(){
		tamanho = 0;
		auxCod = 0;
		inicio = null;
		fim = null;
	}
		
	void inserir(String x, double y, int z){
		NoProduto novo = new NoProduto();
		novo.nome = x;
		novo.preco = y;
		novo.qt = z;
		novo.ant = null;
		if(vazia()){
			fim = novo;
			inicio = novo;
		}else{
			novo.prox = inicio;
			inicio.ant = novo;
			inicio = novo;
		}
		auxCod++;
		novo.codigo = auxCod;
		tamanho++;
		JOptionPane.showMessageDialog(null, "Produto " + novo.nome + ", c�digo " + novo.codigo + ", R$ "+ novo.preco + ", " + novo.qt + " unidades foi cadastrado com sucesso!");
	}
		
	int tamanho(){
		return tamanho;
	}
	
	NoProduto buscar(String x){
		NoProduto aux;
		for(aux = inicio; aux != null; aux = aux.prox){
			if(x.equals(aux.nome)){
				return aux;
			}
		}
			JOptionPane.showMessageDialog(null, "Produto n�o cadastrado!");
			return null;
	}
	
	void remover(String x){
		NoProduto p = buscar(x);
		NoProduto p1, p2;
		if(p == null){
			JOptionPane.showMessageDialog(null, "N�o � poss�vel remover este cliente!");
		}else{
			if(p.prox == null){
				inicio = null;
			}else if(p == inicio){
				p1 = p.prox;
				inicio = p.prox;
				p1.ant = null;
				p.prox = null;
			}else if(p == fim){
				p1 = p.ant;
				fim = p.ant;
				p1.prox = null;
				p.ant = null;
			}else{
				p1 = p.ant;
				p2 = p.prox;
				p1.prox = p2;
				p2.ant = p1;
				p.ant = null;
				p.prox = null;
			}
			tamanho --;
			JOptionPane.showMessageDialog(null, "Cliente "+p.nome+" removido com sucesso!");
		}
	}
	
	void exibir(){
		NoProduto aux = new NoProduto();
		for(aux = inicio; aux != null; aux = aux.prox){
			//textPaneListaProdutos.setText(aux.nome);
		}
		JOptionPane.showMessageDialog(null, "Lista exibida com sucesso!!!");
	}
	
	boolean vazia(){
		if(tamanho == 0){
			return true;
		}else{
			return false;
		}
	}

}