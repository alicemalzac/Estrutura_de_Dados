import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.Font;
import javax.swing.JTextPane;
import javax.swing.border.LineBorder;
import java.awt.Color;
import javax.swing.JList;

public class Aplica��o extends JFrame {

	private JPanel contentPane;
	private final JLabel lblCliente = new JLabel("Cliente:");
	private JTextField textCliente;
	private JTextField textNome;

	/**
	 * Launch the application.
	 */
	
	Clientes c = new Clientes();
	Produtos p = new Produtos();
	private JTextPane textPaneCodigo;
	private JTextField textNomePedido;
	private JTextField textCodigoPedido;
	private JTextField textField;
	private JTextField textField_1;
	private JTextField textField_2;
	private JButton btnIncluir;
	private JTextField textField_3;
	private JTextField textField_4;
	private JTextField textClienteRemover;
	private JTextField textExibirProduto;
	private JTextField textCodigoProduto;
	private JTextField textExPrecoProduto;
	private JTextField textNomeProduto;
	private JTextField textCadPrecoProduto;
	private JTextField textQuantidadeProduto;
	private JTextField textQuantidadeAtual;
	private JTextField textRemoverProduto;
	
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Aplica��o frame = new Aplica��o();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Aplica��o() {
		setTitle("Food Truck");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 700, 520);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		lblCliente.setFont(new Font("Tahoma", Font.PLAIN, 11));
		lblCliente.setBounds(10, 67, 44, 14);
		contentPane.add(lblCliente);
		
		textCliente = new JTextField();
		textCliente.setBounds(55, 64, 167, 20);
		contentPane.add(textCliente);
		textCliente.setColumns(10);
		
		JButton btnBuscarCliente = new JButton("Buscar");
		btnBuscarCliente.setBounds(115, 35, 89, 23);
		btnBuscarCliente.setFont(new Font("Tahoma", Font.PLAIN, 11));
		btnBuscarCliente.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				No aux;
				aux = c.buscar(Integer.valueOf(textPaneCodigo.getText()));
				if(aux != null){
					JOptionPane.showMessageDialog(null, "Cliente encontrado!");
					textCliente.setText(String.valueOf(c.buscar(Integer.valueOf(textPaneCodigo.getText())).nome));
				}else{
					textCliente.setText("");
					textPaneCodigo.setText("");
				}
			}
		});
		contentPane.add(btnBuscarCliente);
		
		JLabel lblNome = new JLabel("Nome:");
		lblNome.setFont(new Font("Tahoma", Font.PLAIN, 11));
		lblNome.setBounds(362, 39, 37, 14);
		contentPane.add(lblNome);
		
		textNome = new JTextField();
		textNome.setBounds(409, 36, 167, 20);
		contentPane.add(textNome);
		textNome.setColumns(10);
		
		JButton btnCadastrar = new JButton("Cadastrar");
		btnCadastrar.setBounds(586, 35, 89, 23);
		btnCadastrar.setFont(new Font("Tahoma", Font.PLAIN, 11));
		btnCadastrar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				c.inserir(textNome.getText());
				textNome.setText("");
			}
		});
		contentPane.add(btnCadastrar);
		
		textPaneCodigo = new JTextPane();
		textPaneCodigo.setBounds(55, 36, 50, 20);
		textPaneCodigo.setBorder(new LineBorder(Color.GRAY));
		contentPane.add(textPaneCodigo);
		textPaneCodigo.setAutoscrolls(false);
		
		JLabel lblCadastrar = new JLabel("Cadastrar Cliente:");
		lblCadastrar.setFont(new Font("Tahoma", Font.PLAIN, 11));
		lblCadastrar.setBounds(362, 11, 89, 14);
		contentPane.add(lblCadastrar);
		
		JLabel lblCodigo = new JLabel("C\u00F3digo:");
		lblCodigo.setFont(new Font("Tahoma", Font.PLAIN, 11));
		lblCodigo.setBounds(10, 40, 46, 14);
		contentPane.add(lblCodigo);
		
		JLabel lblPedidosAnteriores = new JLabel("Pedidos Anteriores:");
		lblPedidosAnteriores.setFont(new Font("Tahoma", Font.PLAIN, 11));
		lblPedidosAnteriores.setBounds(10, 95, 95, 14);
		contentPane.add(lblPedidosAnteriores);
		
		JTextPane textPanePedidosAnteriores = new JTextPane();
		textPanePedidosAnteriores.setBounds(10, 120, 311, 90);
		textPanePedidosAnteriores.setBorder(new LineBorder(Color.LIGHT_GRAY));
		contentPane.add(textPanePedidosAnteriores);
		
		JLabel lblBuscarCliente = new JLabel("Buscar Cliente:");
		lblBuscarCliente.setFont(new Font("Tahoma", Font.PLAIN, 11));
		lblBuscarCliente.setBounds(10, 11, 74, 14);
		contentPane.add(lblBuscarCliente);
		
		JLabel lblPedido = new JLabel("Fazer Novo Pedido:");
		lblPedido.setFont(new Font("Tahoma", Font.PLAIN, 11));
		lblPedido.setBounds(362, 95, 102, 14);
		contentPane.add(lblPedido);
		
		JLabel lblNomePedido = new JLabel("Nome:");
		lblNomePedido.setFont(new Font("Tahoma", Font.PLAIN, 11));
		lblNomePedido.setBounds(362, 122, 37, 14);
		contentPane.add(lblNomePedido);
		
		textNomePedido = new JTextField();
		textNomePedido.setBounds(409, 119, 167, 20);
		contentPane.add(textNomePedido);
		textNomePedido.setColumns(10);
		
		JLabel lblCodigoPedido = new JLabel("C\u00F3digo:");
		lblCodigoPedido.setFont(new Font("Tahoma", Font.PLAIN, 11));
		lblCodigoPedido.setBounds(586, 122, 44, 14);
		contentPane.add(lblCodigoPedido);
		
		textCodigoPedido = new JTextField();
		textCodigoPedido.setBounds(631, 119, 44, 20);
		contentPane.add(textCodigoPedido);
		textCodigoPedido.setColumns(10);
		
		JLabel labelProduto = new JLabel("Produto:");
		labelProduto.setFont(new Font("Tahoma", Font.PLAIN, 11));
		labelProduto.setBounds(362, 150, 46, 14);
		contentPane.add(labelProduto);
		
		textField = new JTextField();
		textField.setBounds(409, 147, 167, 20);
		contentPane.add(textField);
		textField.setColumns(10);
		
		JLabel lblCdigo = new JLabel("C\u00F3digo:");
		lblCdigo.setFont(new Font("Tahoma", Font.PLAIN, 11));
		lblCdigo.setBounds(586, 150, 44, 14);
		contentPane.add(lblCdigo);
		
		textField_1 = new JTextField();
		textField_1.setBounds(631, 147, 44, 20);
		contentPane.add(textField_1);
		textField_1.setColumns(10);
		
		JLabel lblQuantidade = new JLabel("Quantidade:");
		lblQuantidade.setFont(new Font("Tahoma", Font.PLAIN, 11));
		lblQuantidade.setBounds(362, 181, 66, 14);
		contentPane.add(lblQuantidade);
		
		textField_2 = new JTextField();
		textField_2.setBounds(427, 178, 37, 20);
		contentPane.add(textField_2);
		textField_2.setColumns(10);
		
		JLabel lblObs = new JLabel("Obs.:");
		lblObs.setFont(new Font("Tahoma", Font.PLAIN, 11));
		lblObs.setBounds(474, 181, 37, 14);
		contentPane.add(lblObs);
		
		btnIncluir = new JButton("Incluir");
		btnIncluir.setFont(new Font("Tahoma", Font.PLAIN, 11));
		btnIncluir.setBounds(362, 243, 89, 23);
		btnIncluir.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			}
		});
		contentPane.add(btnIncluir);
		
		JButton btnVerificar = new JButton("Verificar");
		btnVerificar.setFont(new Font("Tahoma", Font.PLAIN, 11));
		btnVerificar.setBounds(362, 209, 89, 23);
		contentPane.add(btnVerificar);
		
		JList list = new JList();
		list.setBounds(468, 231, 1, 1);
		contentPane.add(list);
		
		JTextPane textPane = new JTextPane();
		textPane.setBorder(new LineBorder(Color.GRAY));
		textPane.setBounds(510, 178, 165, 20);
		contentPane.add(textPane);
		
		JLabel lblValor = new JLabel("Valor:");
		lblValor.setFont(new Font("Tahoma", Font.PLAIN, 11));
		lblValor.setBounds(474, 213, 37, 14);
		contentPane.add(lblValor);
		
		textField_3 = new JTextField();
		textField_3.setBounds(510, 210, 86, 20);
		contentPane.add(textField_3);
		textField_3.setColumns(10);
		
		JLabel lblTotal = new JLabel("Total:");
		lblTotal.setFont(new Font("Tahoma", Font.PLAIN, 11));
		lblTotal.setBounds(474, 247, 28, 14);
		contentPane.add(lblTotal);
		
		textField_4 = new JTextField();
		textField_4.setBounds(510, 244, 86, 20);
		contentPane.add(textField_4);
		textField_4.setColumns(10);
		
		JLabel lblRemover = new JLabel("Remover Cliente:");
		lblRemover.setFont(new Font("Tahoma", Font.PLAIN, 11));
		lblRemover.setBounds(10, 221, 89, 14);
		contentPane.add(lblRemover);
		
		JLabel lblNomeRemover = new JLabel("Nome:");
		lblNomeRemover.setFont(new Font("Tahoma", Font.PLAIN, 11));
		lblNomeRemover.setBounds(10, 247, 46, 14);
		contentPane.add(lblNomeRemover);
		
		textClienteRemover = new JTextField();
		textClienteRemover.setBounds(55, 244, 169, 20);
		contentPane.add(textClienteRemover);
		textClienteRemover.setColumns(10);
		
		JButton btnRemover = new JButton("Remover");
		btnRemover.setFont(new Font("Tahoma", Font.PLAIN, 11));
		btnRemover.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				c.remover(textClienteRemover.getText());
				textClienteRemover.setText("");
			}
		});
		btnRemover.setBounds(234, 243, 89, 23);
		contentPane.add(btnRemover);
		
		JLabel lblBuscarProduto = new JLabel("Buscar Produto:");
		lblBuscarProduto.setFont(new Font("Tahoma", Font.PLAIN, 11));
		lblBuscarProduto.setBounds(10, 293, 86, 14);
		contentPane.add(lblBuscarProduto);
		
		JLabel lblProduto = new JLabel("Produto:");
		lblProduto.setFont(new Font("Tahoma", Font.PLAIN, 11));
		lblProduto.setBounds(10, 318, 46, 14);
		contentPane.add(lblProduto);
		
		textExibirProduto = new JTextField();
		textExibirProduto.setBounds(55, 315, 167, 20);
		contentPane.add(textExibirProduto);
		textExibirProduto.setColumns(10);
		
		JButton btnBuscarProduto = new JButton("Buscar");
		btnBuscarProduto.setFont(new Font("Tahoma", Font.PLAIN, 11));
		btnBuscarProduto.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				NoProduto aux;
				aux = p.buscar(textExibirProduto.getText());
				if(aux != null){
					JOptionPane.showMessageDialog(null, "Produto encontrado. C�digo: " + aux.codigo);
					textCodigoProduto.setText(String.valueOf(p.buscar(textExibirProduto.getText()).codigo));
					textExPrecoProduto.setText(String.valueOf(p.buscar(textExibirProduto.getText()).preco));
					textQuantidadeAtual.setText(String.valueOf(p.buscar(textExibirProduto.getText()).qt));
				}else{
					textExibirProduto.setText("");
					textCodigoProduto.setText("");
					textExPrecoProduto.setText("");
					textQuantidadeAtual.setText("");
				}
			}
		});
		btnBuscarProduto.setBounds(234, 314, 89, 23);
		contentPane.add(btnBuscarProduto);
		
		JLabel lblCdigo_1 = new JLabel("C\u00F3digo:");
		lblCdigo_1.setFont(new Font("Tahoma", Font.PLAIN, 11));
		lblCdigo_1.setBounds(10, 346, 46, 14);
		contentPane.add(lblCdigo_1);
		
		textCodigoProduto = new JTextField();
		textCodigoProduto.setBounds(55, 343, 50, 20);
		contentPane.add(textCodigoProduto);
		textCodigoProduto.setColumns(10);
		
		JLabel lblPreco = new JLabel("Pre\u00E7o:");
		lblPreco.setFont(new Font("Tahoma", Font.PLAIN, 11));
		lblPreco.setBounds(115, 346, 37, 14);
		contentPane.add(lblPreco);
		
		textExPrecoProduto = new JTextField();
		textExPrecoProduto.setBounds(156, 343, 66, 20);
		contentPane.add(textExPrecoProduto);
		textExPrecoProduto.setColumns(10);
		
		JLabel lblCadastrarProduto = new JLabel("Cadastrar Produto:");
		lblCadastrarProduto.setFont(new Font("Tahoma", Font.PLAIN, 11));
		lblCadastrarProduto.setBounds(362, 293, 102, 14);
		contentPane.add(lblCadastrarProduto);
		
		JLabel lblNomeProduto = new JLabel("Nome:");
		lblNomeProduto.setFont(new Font("Tahoma", Font.PLAIN, 11));
		lblNomeProduto.setBounds(362, 318, 37, 14);
		contentPane.add(lblNomeProduto);
		
		textNomeProduto = new JTextField();
		textNomeProduto.setBounds(409, 315, 167, 20);
		contentPane.add(textNomeProduto);
		textNomeProduto.setColumns(10);
		
		JLabel lblPrecoProduto = new JLabel("Pre\u00E7o:");
		lblPrecoProduto.setFont(new Font("Tahoma", Font.PLAIN, 11));
		lblPrecoProduto.setBounds(362, 346, 46, 14);
		contentPane.add(lblPrecoProduto);
		
		textCadPrecoProduto = new JTextField();
		textCadPrecoProduto.setBounds(409, 343, 55, 20);
		contentPane.add(textCadPrecoProduto);
		textCadPrecoProduto.setColumns(10);
		
		JLabel lblQuantidadeProduto = new JLabel("Quantidade:");
		lblQuantidadeProduto.setFont(new Font("Tahoma", Font.PLAIN, 11));
		lblQuantidadeProduto.setBounds(474, 346, 66, 14);
		contentPane.add(lblQuantidadeProduto);
		
		textQuantidadeProduto = new JTextField();
		textQuantidadeProduto.setBounds(541, 343, 35, 20);
		contentPane.add(textQuantidadeProduto);
		textQuantidadeProduto.setColumns(10);
		
		JButton btnCadastrarProduto = new JButton("Cadastrar");
		btnCadastrarProduto.setFont(new Font("Tahoma", Font.PLAIN, 11));
		btnCadastrarProduto.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				p.inserir(textNomeProduto.getText(), Double.valueOf(textCadPrecoProduto.getText()), Integer.valueOf(textQuantidadeProduto.getText()));
				textNomeProduto.setText("");
				textCadPrecoProduto.setText("");
				textQuantidadeProduto.setText("");
			}
		});
		btnCadastrarProduto.setBounds(586, 314, 89, 23);
		contentPane.add(btnCadastrarProduto);
		
		JLabel lblQuantidadeAtual = new JLabel("Quantidade Atual:");
		lblQuantidadeAtual.setFont(new Font("Tahoma", Font.PLAIN, 11));
		lblQuantidadeAtual.setBounds(10, 374, 95, 14);
		contentPane.add(lblQuantidadeAtual);
		
		textQuantidadeAtual = new JTextField();
		textQuantidadeAtual.setBounds(108, 371, 37, 20);
		contentPane.add(textQuantidadeAtual);
		textQuantidadeAtual.setColumns(10);
		
		JLabel lblRemoverProduto = new JLabel("Remover Produto:");
		lblRemoverProduto.setFont(new Font("Tahoma", Font.PLAIN, 11));
		lblRemoverProduto.setBounds(10, 417, 95, 14);
		contentPane.add(lblRemoverProduto);
		
		JLabel lblRemProduto = new JLabel("Produto:");
		lblRemProduto.setFont(new Font("Tahoma", Font.PLAIN, 11));
		lblRemProduto.setBounds(10, 442, 46, 14);
		contentPane.add(lblRemProduto);
		
		textRemoverProduto = new JTextField();
		textRemoverProduto.setBounds(55, 439, 167, 20);
		contentPane.add(textRemoverProduto);
		textRemoverProduto.setColumns(10);
		
		JButton btnRemoverProduto = new JButton("Remover");
		btnRemoverProduto.setFont(new Font("Tahoma", Font.PLAIN, 11));
		btnRemoverProduto.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				p.remover(textRemoverProduto.getText());
				textRemoverProduto.setText("");
			}
		});
		btnRemoverProduto.setBounds(232, 438, 89, 23);
		contentPane.add(btnRemoverProduto);
		
		JLabel lblListaDeProdutos = new JLabel("Lista de Produtos Cadastrados:");
		lblListaDeProdutos.setBounds(362, 377, 157, 14);
		contentPane.add(lblListaDeProdutos);
		
		JTextPane textPaneListaProdutos = new JTextPane();
		textPaneListaProdutos.setFont(new Font("Tahoma", Font.PLAIN, 11));
		textPaneListaProdutos.setEditable(true);
		textPaneListaProdutos.setBounds(362, 402, 312, 68);
		contentPane.add(textPaneListaProdutos);
		
		JButton btnListarProdutos = new JButton("Listar");
		btnListarProdutos.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
			}
		});
		btnListarProdutos.setBounds(586, 373, 89, 23);
		contentPane.add(btnListarProdutos);
	}
}
