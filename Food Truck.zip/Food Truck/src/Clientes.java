import javax.swing.JOptionPane;

public class Clientes {
	private int tamanho, auxCod;
	private No inicio;
	private No fim;
		
	public Clientes(){
		tamanho = 0;
		auxCod = 0;
		inicio = null;
		fim = null;
	}
	
	void inserir(String x){
		No novo = new No();
		novo.nome = x;
		novo.ant = null;
		if(vazia()){
			fim = novo;
			inicio = novo;
		}else{
			novo.prox = inicio;
			inicio.ant = novo;
			inicio = novo;
		}
		auxCod++;
		novo.codigo = auxCod;
		tamanho++;
		JOptionPane.showMessageDialog(null, "Cliente " + novo.nome + ", c�digo " + novo.codigo + " cadastrado com sucesso!");
	}
	
	int tamanho(){
		return tamanho;
	}
	
	No buscar(String x){
		No aux;
		for(aux = inicio; aux != null; aux = aux.prox){
			if(x.equals(aux.nome)){
				return aux;
			}
		}
			JOptionPane.showMessageDialog(null, "Cliente n�o cadastrado!");
			return null;
	}
	
	No buscar(int x){
		No aux;
		for(aux = inicio; aux != null; aux = aux.prox){
			if(x == aux.codigo){
				return aux;
			}
		}
			JOptionPane.showMessageDialog(null, "Cliente n�o cadastrado!");
			return null;
	}
	
	void remover(String x){
		No p = buscar(x);
		No p1, p2;
		if(p == null){
			JOptionPane.showMessageDialog(null, "N�o � poss�vel remover este cliente!");
		}else{
			if(p.prox == null){
				inicio = null;
			}else if(p == inicio){
				p1 = p.prox;
				inicio = p.prox;
				p1.ant = null;
				p.prox = null;
			}else if(p == fim){
				p1 = p.ant;
				fim = p.ant;
				p1.prox = null;
				p.ant = null;
			}else{
				p1 = p.ant;
				p2 = p.prox;
				p1.prox = p2;
				p2.ant = p1;
				p.ant = null;
				p.prox = null;
			}
			tamanho --;
			JOptionPane.showMessageDialog(null, "Cliente "+p.nome+" removido com sucesso!");
		}
	}
	
	boolean vazia(){
		if(tamanho == 0){
			return true;
		}else{
			return false;
		}
	}

}