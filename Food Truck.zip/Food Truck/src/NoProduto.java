
public class NoProduto {
	public int codigo, qt;
	public double preco;
	public String nome;
	public NoProduto prox;
	public NoProduto ant;
}
