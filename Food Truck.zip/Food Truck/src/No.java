
public class No {
	public int codigo;
	public String nome;
	public No prox;
	public No ant;
}