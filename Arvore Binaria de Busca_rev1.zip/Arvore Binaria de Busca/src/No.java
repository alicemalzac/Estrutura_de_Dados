
public class No {
	public int valor;
	public No esq;
	public No dir;
}
