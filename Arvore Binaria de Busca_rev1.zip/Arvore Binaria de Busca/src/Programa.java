
public class Programa {

	public static void main(String[] args) {
		ArvoreBinariaBusca a = new ArvoreBinariaBusca();
		
		a.inserir(9);
		a.inserir(4);
		a.inserir(6);
		a.inserir(5);
		a.inserir(7);
		a.inserir(2);
		a.inserir(1);
		a.inserir(12);
		a.inserir(15);
		a.inserir(11);
		a.inserir(13);
		a.inserir(16);
		a.inserir(18);
		
		a.inOrdem();
		
		System.out.println();
		System.out.println(a.buscar(4).valor);

	}

}
