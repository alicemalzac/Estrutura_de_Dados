
public class ArvoreBinariaBusca {
	private int total;
	private No raiz;
	
	ArvoreBinariaBusca(){
		total = 0;
		raiz = null;
	}
	
	void inOrdem(){
		//System.out.println();
		System.out.println("Exibindo elementos da árvore:");
		inOrdem(raiz);
	}
	
	void inOrdem(No aux){ //Método escolhido para na estrutura de dado ÁRVORE BINÁRIA BUSCA exibir os valores em ordem crescente.
		if(aux != null){
			inOrdem(aux.esq);
			System.out.print(aux.valor + ", ");
			inOrdem(aux.dir);
		}else{
			
		}
	}
	
	void inserir(int x){
		if(raiz == null){ //Checa se raiz é null (não existe raiz);
			No aux = new No(); //Cria novo nó;
			aux.valor = x; //Insere o valor de x no novo nó;
			raiz = aux; //Raiz recebe o novo nó;
			total++; //Incrementa o total;
		}else{
			inserir(x, raiz); //Chama-se o método com parâmetro (valor int de x, começa a comparar desde a raiz).
		}
	}
	
	void inserir(int x, No aux){
		if(x <= aux.valor){ //Compara o valor do novo elemento ao da raiz;
			if(aux.esq == null){ //Compara se não há um elemento a esquerda para inserí-lo;
				No k = new No(); //Cria um novo nó;
				k.valor = x; //Insere o valor de x ao novo nó;
				aux.esq = k; //Insere o novo nó a esquerda da raiz;
				total++; //Incrementa o total de nós inseridos.
			}
			else{
				inserir(x,aux.esq); //Se não, será chamada novamente a função por recurssão.
			}
		}else{
			if(aux.dir == null){
				No k = new No();
				k.valor = x;
				aux.dir = k;
				total++;
			}
			else{
				inserir(x,aux.dir);
			}
		}
	}
	
	No buscar(int x){ //Método buscar:
		No aux = raiz; //atribui o valor da raiz a um nó auxiliar;
		while(aux != null){ //Cria um laço while;
			if(x == aux.valor){ //Compara o valor do nó ao desejado;
				return aux; // Se encontrado, retorna o nó.
			}else if(x < aux.valor){ //Senão, compara para saber se tem valor menor que a raiz;
				aux = aux.esq; //Se sim, faz com que a busca siga para a esquerda.
			}else if(x > aux.valor){ //Se não, faz uma nova comparação para saber se o valor buscado é menor que o da raiz;
				aux = aux.dir; //Se sim, faz com que a busca siga para a direita.
			} //Completado o ciclo, retorna ao inicio do while até que seja encontrado um nó null.
		}
		return null;
	}
	
	void remover (int x){
		No atual = raiz;
		No ant = null;
		while(atual != null){
			if(x == atual.valor){
				if(atual == raiz){ //Remove a raiz;
					ant.dir = removeNo(atual);
					//raiz = ??? -> este elemento será ou o maior do lado esquerdo, ou o menor do lado direito.
				}else if(ant.esq == atual){ //Remove o nó a esquerda do anterior;
					ant.dir = removeNo(atual);
					//ant.esq = ??? -> este elemento será o maior do lado direito.
				}else if(ant.dir == atual){ //Remove o nó a direita do anterior;
					ant.dir = removeNo(atual);
					//ant.dir = ??? -> este elemento será o menor do lado esquerdo.
				}
				break;
			}else if(x < atual.valor){
				ant = atual;
				atual = atual.esq;
			}else if(x > atual.valor){
				ant = atual;
				atual = atual.dir;
			}
		}
	}
	
	No removeNo(No atual){
		No no1;
		No no2;
		if(atual.esq == null){
			no1 = atual.dir;
			return no1;
		}else{ //Será usado o maior da esquerda para substituir uma raiz.
			no2 = atual.esq;
			while(no2.dir != null){
				no2 = no2.dir;
				}
			//troca no2 com o atual;
			//remove o no2;
		}
		
		return null;
	}
	
}
