package Fila;

public class FILA {
final int SUCESSO = 0;
final int FILA_CHEIA = 1;
final int FILA_VAZIA = 2;
private final int m = 15;
private int primeiro;
private int ultimo;
private String [] elem = new String [m];

//------------------------------- criaFila

public void criaFila(){
primeiro = 0;
ultimo = -1;
}

//------------------------------- insereFila

public int insereFila(String dado){
if (ultimo == m -1){
return(FILA_CHEIA);
} else {
ultimo++; // incrementa no ultimo
elem[ultimo] = dado;
return SUCESSO;
}
}

//------------------------------- excluiFila

public String excluiFila(){
if (ultimo == -1) {
System.out.println("Erro! Fila vazia!");
return(String.valueOf(FILA_VAZIA));
} else {
System.out.println("Cliente Atendido: " + elem[primeiro]);
primeiro++; // muda ponteiro para o pr�ximo elemento.
if ( primeiro > ultimo){
primeiro = 0;
ultimo = -1;
}

return String.valueOf(SUCESSO);
}
}

//------------------------------- consultaFila

public String consultaFila(){
if(ultimo == -1){
return(null);
} else {
return(elem[primeiro]); //retorna onde est� o ponteiro primeiro
}
}

//------------------------------- exibeFila

public void exibeFila(){
System.out.println("Fila de Clientes: ");
if(ultimo != -1){
for( int i = primeiro; i <= ultimo ; i++){
System.out.print(elem[i]+ " | ");
}
System.out.println();
}
}

//------------------------------- imprimeErro

public void imprimeErro(int erro){
switch (erro) {
case FILA_CHEIA: System.out.println("Erro! Fila cheia!");
break;
case FILA_VAZIA: System.out.println("Erro! Fila vazia!");
break;
}
}
}
