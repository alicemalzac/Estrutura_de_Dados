package Fila;

import java.util.Scanner;

import com.sun.security.ntlm.Client;

public class Main {

	public static void main(String[] args) {
		Scanner entrada = new Scanner(System.in);
		String s;

		FILA fila = new FILA();
		FILAPEDIDO filaped = new FILAPEDIDO();
		FILACLIENTES filacli = new FILACLIENTES();

		String cliente;
		String pedido;
		String clientePerm;

		int erro = 0;
		char ch;

		fila.criaFila();
		filaped.criaFila();
		filacli.criaFila();

		System.err.println("- FoodTruck! - ");
		do {

			System.out.println("");
			System.out
					.print("Digite uma das op��es: [I]ncluir | [A]tender | [C]onsultar Pr�ximo | [L]istar  | Lista[R] Clientes | E[X]cluir Clientes | [F]im? - ");
			do {
				s = entrada.nextLine();
				ch = s.charAt(0);
				ch = Character.toLowerCase(ch);
			} while (ch != 'i' && ch != 'a' && ch != 'c' && ch != 'f'
					&& ch != 'l' && ch != 'r' && ch != 'x');

			switch (ch) {
			case 'i':
				System.out.printf("Nome do Cliente: ");
				s = entrada.nextLine();
				cliente = s;
				erro = fila.insereFila(cliente);
				clientePerm = s;
				erro = filacli.insereFila(clientePerm);

				System.out.printf("Pedido: ");
				s = entrada.nextLine();
				pedido = s;
				erro = filaped.insereFila(pedido);

				if (erro != 0)
					fila.imprimeErro(erro);

				break;
			case 'a':
				cliente = fila.excluiFila();
				pedido = filaped.excluiFila();

				break;
			case 'r':
				filacli.exibeFila();
				break;

			case 'x':
				filacli.excluiFila();
				break;
				
			case 'l':
				fila.exibeFila();
				filaped.exibeFila();
				break;
				
			case 'c':
				cliente = fila.consultaFila();
				pedido = filaped.consultaFila();
				if (cliente != null && pedido != null) {
					System.out.println("Primeiro da fila: " + cliente);
					System.out
							.println("Pedido de " + cliente + " �: " + pedido);
				} else {
					System.out.println("Erro! Lista Vazia!");
				}
				break;
			}

		} while (ch != 'f');
		System.err.println("Programa terminado!");
		System.exit(0);
	}
}
